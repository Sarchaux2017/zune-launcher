# Zune Launcher

1. Android Studio (Ladybug or newer) -> Open -> select this folder. Let Gradle sync (it generates the wrapper).
2. Optional: put OpenWeatherMap / AlphaVantage keys + city in `gradle.properties`. Blank keys = simulated feeds.
3. Run on the Pixel 6, press Home, choose "Zune Launcher" -> "Always".
   (Or Settings > Apps > Default apps > Home app.)

Gestures: swipe or tap headers to pivot; long-press an app for its App Info; long-press your name to change it.
